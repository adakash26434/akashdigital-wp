<?php
/**
 * Simple database connection test
 * Place this in the root directory to test DB connection
 */

// Get database config from environment or defaults
$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbName = getenv('DB_NAME') ?: 'your_database_name';
$dbUser = getenv('DB_USER') ?: 'your_database_user';
$dbPass = getenv('DB_PASS') ?: '';
$dbDriver = getenv('DB_DRIVER') ?: '';

echo "<h1>Database Connection Test</h1>";
echo "<p>DB_DRIVER: " . htmlspecialchars($dbDriver ?: '(not set)') . "</p>";
echo "<p>DB_HOST: " . htmlspecialchars($dbHost) . "</p>";
echo "<p>DB_NAME: " . htmlspecialchars($dbName) . "</p>";
echo "<p>DB_USER: " . htmlspecialchars($dbUser) . "</p>";
echo "<p>DB_PASS: " . ($dbPass ? '*** (set)' : '(empty)') . "</p>";

if ($dbDriver === 'sqlite') {
    $dbPath = getenv('DB_SQLITE_PATH') ?: __DIR__ . '/data/site.db';
    echo "<p>SQLite Path: " . htmlspecialchars($dbPath) . "</p>";
    echo "<p>SQLite Path Exists: " . (file_exists($dbPath) ? 'Yes' : 'No') . "</p>";
    
    try {
        $pdo = new PDO('sqlite:' . $dbPath);
        echo "<p style='color:green;'>✓ SQLite connected successfully</p>";
        
        // Check for site_settings table
        $result = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='site_settings'");
        if ($result->fetch()) {
            echo "<p>✓ site_settings table exists</p>";
        } else {
            echo "<p>✗ site_settings table does not exist</p>";
        }
    } catch (PDOException $e) {
        echo "<p style='color:red;'>✗ SQLite connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
} else {
    // MySQL/MariaDB
    $socket = getenv('MYSQL_SOCKET') ?: '/tmp/mysql.sock';
    if (file_exists($socket)) {
        $dsn = "mysql:unix_socket={$socket};dbname={$dbName};charset=utf8mb4";
    } else {
        $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    }
    
    try {
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        echo "<p style='color:green;'>✓ MySQL connected successfully</p>";
        
        // Check for site_settings table
        try {
            $result = $pdo->query("SHOW TABLES LIKE 'site_settings'");
            if ($result->fetch()) {
                echo "<p>✓ site_settings table exists</p>";
            } else {
                echo "<p>✗ site_settings table does not exist</p>";
            }
        } catch (PDOException $e) {
            echo "<p>Table check failed: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } catch (PDOException $e) {
        echo "<p style='color:red;'>✗ MySQL connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}