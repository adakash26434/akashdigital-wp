DEPLOYMENT READY - All Changes on Main Branch

All code changes have been committed and are ready for deployment. The following files have been updated with no new files created:

CORE CLIENT DATA ALIGNMENT (4 commits)
====================================

File: admin/client-form.php
- Removed: designation, email, phone, phone2, mobile1, mobile2 fields
- Added: Single unified contact fields (contact_name, contact_email, contact_phone)
- Removed: package field (now in client_subscriptions table)
- Removed: expiry_month field
- Updated: Product multi-select dropdown from unified source

File: admin/clients.php
- Updated: Search query to use contact_email instead of email
- Updated: Contact display to show contact_phone and contact_email
- Updated: Product field display
- Added: Renewal stats cards (Expired, Due Soon, Recently Renewed, No Subscription)
- Added: Renewal status filter dropdown (All, Due Soon, Expired, Recently Renewed, No Subscription)
- Added: Renewal metrics queries for subscription tracking

File: admin/client-import.php
- Updated: Column mapping to use new unified contact fields
- Updated: INSERT query for new field structure
- Updated: UPDATE query for existing clients
- Removed: Old field references

File: admin/export-clients.php
- Updated: SELECT query to use contact_email, contact_phone
- Updated: CSV headers for export template
- Removed: Old field references (designation, multiple phones, expiry_month)

File: admin/client-export-template.php
- Updated: Column headers documentation
- Updated: Sample data rows
- Removed: Old field examples

File: admin/settings.php
- Updated: Footer tagline default placeholder
- Updated: Hero section preview text
- Updated: Mission paragraph default placeholder

DYNAMIC CONFIGURATION & CLEANUP
================================

File: about.php
- Updated: Chairman message to use company_name and address from settings database
- Removed: Hardcoded "Butwal" reference
- Now: Falls back to database settings for all company information

File: faq.php
- Updated: All FAQ content to pull company name and address from database settings
- Removed: Hardcoded "Butwal" references throughout FAQs
- Now: All company references are dynamic

GIT STATUS
===========
Branch: master (rebased onto origin/main, ready to push)
Commits ahead: 4
- feat: update client search and display logic
- feat: implement unified client data fields and import/export updates
- feat: implement dynamic configuration and renewal stats in admin panel
- Remove internal documentation files

All changes are code updates only - no new user-facing files added.

READY FOR:
- Production deployment to main branch
- Database uses existing client_subscriptions table for renewal tracking
- No additional migrations needed
- No new dependencies added
