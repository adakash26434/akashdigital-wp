<?php
/**
 * Database Schema Migrations
 * Run this to update table structures for new features
 */

function runDbMigrations() {
    // Migration 0: Create site_settings table if it doesn't exist
    try {
        $result = query("SHOW TABLES LIKE 'site_settings'");
        if (empty($result)) {
            // Table doesn't exist, create it
            if (defined('DB_DRIVER') && DB_DRIVER === 'sqlite') {
                execute("CREATE TABLE IF NOT EXISTS site_settings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    setting_key TEXT NOT NULL UNIQUE,
                    setting_val TEXT,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )");
            } else {
                execute("CREATE TABLE IF NOT EXISTS site_settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    setting_key VARCHAR(100) NOT NULL UNIQUE,
                    setting_val LONGTEXT,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_key (setting_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            }
            // Seed default values
            saveSetting('site_name', defined('SITE_NAME') ? SITE_NAME : 'Company');
            saveSetting('site_tagline', 'Cooperative Software for Nepal');
            saveSetting('company_name', defined('SITE_NAME') ? SITE_NAME : 'Company');
            saveSetting('address', 'Kathmandu, Nepal');
        }
    } catch (\Throwable $e) {
        error_log('[db-migrations] site_settings table creation failed: ' . $e->getMessage());
    }

    try {
        // Migration 1: Add team category field
        $result = execute("SHOW COLUMNS FROM team_members LIKE 'category'");
        if (empty($result)) {
            execute("ALTER TABLE team_members ADD COLUMN category TEXT DEFAULT 'management' AFTER is_leadership");
        }
    } catch (\Throwable $e) {
        // Column might already exist or SQLite (which doesn't support ALTER)
    }

    try {
        // Migration 2: Seed company_name + developer attribution if not exist
        $check = queryOne("SELECT id FROM site_settings WHERE setting_key=?", ['company_name']);
        if (!$check) {
            saveSetting('company_name', defined('SITE_NAME') ? SITE_NAME : 'Company');
            saveSetting('developed_by_name', defined('SITE_NAME') ? SITE_NAME : 'Company');
            saveSetting('developed_by_url', '');
        }
    } catch (\Throwable $e) {
        // site_settings might not be available
    }

    try {
        // Migration 3: Add client_code column to users table (signup flow)
        $result = query("SHOW COLUMNS FROM users LIKE 'client_code'");
        if (empty($result)) {
            execute("ALTER TABLE users ADD COLUMN client_code VARCHAR(50) NULL AFTER org_name");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 4: Add email, phone, address columns to partners table (for channel partners)
        $result = query("SHOW COLUMNS FROM partners LIKE 'email'");
        if (empty($result)) {
            execute("ALTER TABLE partners ADD COLUMN email VARCHAR(255) NULL AFTER url");
            execute("ALTER TABLE partners ADD COLUMN phone VARCHAR(50) NULL AFTER email");
            execute("ALTER TABLE partners ADD COLUMN address TEXT NULL AFTER phone");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 5: Notices table for admin announcements popup
        $result = query("SHOW COLUMNS FROM notices LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS notices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(255) NOT NULL,
                content TEXT NOT NULL,
                image_url VARCHAR(500) DEFAULT NULL,
                target_pages VARCHAR(255) DEFAULT 'all',
                is_active TINYINT(1) DEFAULT 1,
                starts_at DATETIME DEFAULT NULL,
                ends_at DATETIME DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER DEFAULT NULL
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 6: Agreement templates table
        $result = query("SHOW COLUMNS FROM agreement_templates LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS agreement_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(255) NOT NULL,
                template_type VARCHAR(50) NOT NULL,
                template_content TEXT DEFAULT NULL,
                word_file_path VARCHAR(500) DEFAULT NULL,
                is_default TINYINT(1) DEFAULT 0,
                created_by INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 7: AMC renewal configuration table
        $result = query("SHOW COLUMNS FROM amc_renewal_config LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS amc_renewal_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                renewal_cycle VARCHAR(20) DEFAULT 'yearly',
                cycle_months INTEGER DEFAULT 12,
                increment_type VARCHAR(20) DEFAULT 'fixed',
                increment_value DECIMAL(10,2) DEFAULT 0,
                base_amc_ho DECIMAL(10,2) DEFAULT 0,
                base_amc_branch DECIMAL(10,2) DEFAULT 0,
                next_renewal_date DATE DEFAULT NULL,
                last_renewal_date DATE DEFAULT NULL,
                last_revision_date DATE DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 8: Client agreements table
        $result = query("SHOW COLUMNS FROM client_agreements LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS client_agreements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                agreement_type VARCHAR(50) DEFAULT 'service',
                title VARCHAR(255) NOT NULL,
                document_url VARCHAR(500) DEFAULT NULL,
                document_name VARCHAR(255) DEFAULT NULL,
                effective_date DATE DEFAULT NULL,
                expiry_date DATE DEFAULT NULL,
                amount DECIMAL(12,2) DEFAULT 0,
                status VARCHAR(20) DEFAULT 'pending',
                approved_by INTEGER DEFAULT NULL,
                approved_at DATETIME DEFAULT NULL,
                approval_notes TEXT DEFAULT NULL,
                sale_by INTEGER DEFAULT NULL,
                created_by INTEGER DEFAULT NULL,
                uploaded_by VARCHAR(20) DEFAULT 'admin',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 9: Client charge history table
        $result = query("SHOW COLUMNS FROM client_charge_history LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS client_charge_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                charge_type VARCHAR(50) NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                description TEXT DEFAULT NULL,
                invoice_id INTEGER DEFAULT NULL,
                created_by INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 10: Client documents table
        $result = query("SHOW COLUMNS FROM client_documents LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS client_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                document_type VARCHAR(50) DEFAULT 'other',
                document_name VARCHAR(255) NOT NULL,
                document_url VARCHAR(500) DEFAULT NULL,
                expiry_date DATE DEFAULT NULL,
                verified TINYINT(1) DEFAULT 0,
                verified_by INTEGER DEFAULT NULL,
                verified_at DATETIME DEFAULT NULL,
                created_by INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 11: Client termination table
        $result = query("SHOW COLUMNS FROM client_termination LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS client_termination (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                termination_type VARCHAR(50) DEFAULT 'voluntary',
                reason TEXT DEFAULT NULL,
                termination_date DATE NOT NULL,
                final_amount DECIMAL(12,2) DEFAULT 0,
                settled TINYINT(1) DEFAULT 0,
                settled_by INTEGER DEFAULT NULL,
                settled_at DATETIME DEFAULT NULL,
                approved_by INTEGER DEFAULT NULL,
                approved_at DATETIME DEFAULT NULL,
                created_by INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 12: Invoices table
        $result = query("SHOW COLUMNS FROM invoices LIKE 'id'");
        if (empty($result)) {
            execute("CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_number VARCHAR(50) UNIQUE NOT NULL,
                client_id INTEGER DEFAULT NULL,
                user_id INTEGER DEFAULT NULL,
                due_date DATE DEFAULT NULL,
                notes TEXT DEFAULT NULL,
                terms TEXT DEFAULT NULL,
                tax_rate DECIMAL(5,2) DEFAULT 0,
                subtotal DECIMAL(12,2) DEFAULT 0,
                tax_amount DECIMAL(12,2) DEFAULT 0,
                total_amount DECIMAL(12,2) DEFAULT 0,
                status VARCHAR(20) DEFAULT 'draft',
                paid_at DATETIME DEFAULT NULL,
                created_by INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 14: Add missing columns to clients table
        $cols = ['user_id', 'client_code', 'head_office_amc', 'branch_office_amc'];
        foreach ($cols as $col) {
            $result = query("SHOW COLUMNS FROM clients LIKE ?", [$col]);
            if (empty($result)) {
                $type = $col === 'user_id' ? 'INTEGER DEFAULT NULL' : 'TEXT DEFAULT NULL';
                execute("ALTER TABLE clients ADD COLUMN $col $type");
            }
        }
        // Add contact_name column (pulled from users table or stored directly)
        $result = query("SHOW COLUMNS FROM clients LIKE 'contact_name'");
        if (empty($result)) {
            execute("ALTER TABLE clients ADD COLUMN contact_name TEXT DEFAULT NULL AFTER contact_phone");
        }
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

    try {
        // Migration 15: Add indexes for performance (if not exist)
        execute("CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status)");
        execute("CREATE INDEX IF NOT EXISTS idx_clients_user_id ON clients(user_id)");
        execute("CREATE INDEX IF NOT EXISTS idx_invoices_client_id ON invoices(client_id)");
        execute("CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status)");
        execute("CREATE INDEX IF NOT EXISTS idx_tickets_client_id ON tickets(client_id)");
        execute("CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)");
        execute("CREATE INDEX IF NOT EXISTS idx_client_subscriptions_client_id ON client_subscriptions(client_id)");
        execute("CREATE INDEX IF NOT EXISTS idx_notices_active ON notices(is_active, starts_at, ends_at)");
        // Login/Auth optimization
        execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)");
        execute("CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)");
        // CRM optimization
        execute("CREATE INDEX IF NOT EXISTS idx_crm_leads_stage ON crm_leads(stage)");
        execute("CREATE INDEX IF NOT EXISTS idx_crm_leads_next_followup ON crm_leads(next_followup)");
        execute("CREATE INDEX IF NOT EXISTS idx_crm_leads_assigned ON crm_leads(assigned_to)");
        execute("CREATE INDEX IF NOT EXISTS idx_crm_followups_lead_id ON crm_followups(lead_id)");
        // API & Demo optimization
        execute("CREATE INDEX IF NOT EXISTS idx_api_tokens_client ON api_tokens(client_id)");
        execute("CREATE INDEX IF NOT EXISTS idx_demo_requests_status ON demo_requests(status)");
        execute("CREATE INDEX IF NOT EXISTS idx_contact_submissions_status ON contact_submissions(status)");
    } catch (\Throwable $e) { error_log('[db-migrations] ' . $e->getMessage()); }

}

// Auto-run on page load if needed (optional)
// Call this from config.php or run manually when needed
