<?php
/**
 * Local Development Override
 * This file enables SQLite mode for local/dev environments
 */

// Enable SQLite for development
define('DB_DRIVER', 'sqlite');
define('DB_SQLITE_PATH', __DIR__ . '/../data/site.db');

// Detect and set SITE_URL based on server host
$host = $_SERVER['HTTP_HOST'] ?? '';
if (strpos($host, 'work-1') !== false) {
    define('SITE_URL', 'https://work-1-feoiftuwsbxmhowo.prod-runtime.all-hands.dev');
} elseif (strpos($host, 'work-2') !== false) {
    define('SITE_URL', 'https://work-2-feoiftuwsbxmhowo.prod-runtime.all-hands.dev');
} else {
    define('SITE_URL', 'https://' . $host);
}

// Development mode - shows errors for debugging
define('APP_ENV', 'development');
